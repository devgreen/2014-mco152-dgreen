package green.nytimes;

import java.net.URL;

public class Docs {

	private String lead_paragraph;
	private Headline headline;
	private URL web_url;

	public String getLead_paragraph() {
		return lead_paragraph;
	}

	public Headline getHeadline() {
		return headline;
	}

	public URL getWeb_url() {
		return web_url;
	}

}
