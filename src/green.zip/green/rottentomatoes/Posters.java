package green.rottentomatoes;

import java.net.URL;

public class Posters {
	
	String thumbnail;

	public String getThumbnail() {
		return thumbnail;
	}

}
