package green.rottentomatoes;

public class Movies {

	String id;
	String title;
	Posters posters;

	public String getTitle() {
		return title;
	}

	public String getId() {
		return id;
	}

	public Posters getPosters() {
		return posters;
	}

}
