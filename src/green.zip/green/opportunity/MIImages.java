package green.opportunity;

public class MIImages {

	Images[] images;

	public Images[] getImages() {
		return images;
	}

}
