package green.opportunity;

public class Images {

	String url;

	public String getUrl() {
		return url;
	}

}
