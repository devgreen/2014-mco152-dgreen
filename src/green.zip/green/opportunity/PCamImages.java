package green.opportunity;

public class PCamImages {
	
	Images [] images;

	public Images[] getImages() {
		return images;
	}

}
