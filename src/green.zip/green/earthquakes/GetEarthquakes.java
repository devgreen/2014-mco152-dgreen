package green.earthquakes;

public class GetEarthquakes {

	private Features [] features;

	public Features[] getFeatures() {
		return features;
	}

}
