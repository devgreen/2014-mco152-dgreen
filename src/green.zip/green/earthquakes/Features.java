package green.earthquakes;

public class Features {
	
	private Properties properties;

	public Properties getProperties() {
		return properties;
	}

	

}
