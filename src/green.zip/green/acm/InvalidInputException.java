package green.acm;

public class InvalidInputException extends Exception {

}
