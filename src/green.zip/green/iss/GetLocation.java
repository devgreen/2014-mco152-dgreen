package green.iss;

public class GetLocation {

	private Res [] response;

	public Res[] getResponse() {
		return response;
	}

}
