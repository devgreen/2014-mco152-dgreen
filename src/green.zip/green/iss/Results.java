package green.iss;

public class Results {

	private Geometry geometry;

	public Geometry getGeometry() {
		return geometry;
	}

}
