package green.iss;

public class GetResults {
	
	private Results [] results;

	public Results [] getResults() {
		return results;
	}


}
