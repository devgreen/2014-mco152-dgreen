package green.nytimes;

public class GetResponse {

	private Response response;

	public Response getResponse() {
		return response;
	}

}
