package green.test1;

public class NotEnoughSeatsTogeatherException extends Exception {

	private static final long serialVersionUID = 1L;

}
