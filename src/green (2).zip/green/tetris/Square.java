package green.tetris;

public class Square {
	
	

}
