package green.weather;

public class WeatherNow {

	private String name;
	private Weather [] weather;
	private Main main;
	public String getName() {
		return name;
	}

	public Weather [] getWeather() {
		return weather;
	}
	
	public Main getMain() {
		return main;
	}
	
}
