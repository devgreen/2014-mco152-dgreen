package green.test1;

public class FullPlaneException extends Exception {

	private static final long serialVersionUID = 1L;

}
