package green.rottentomatoes;

public class GetResponse {

	private Movies[] movies;

	public Movies[] getMovies() {
		return movies;
	}

}
