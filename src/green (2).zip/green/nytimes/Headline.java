package green.nytimes;

public class Headline {
	
	private String main;

	public String getMain() {
		return main;
	}

	

}
