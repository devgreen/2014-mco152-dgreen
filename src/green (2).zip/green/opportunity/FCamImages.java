package green.opportunity;

public class FCamImages {

	Images[] images;

	public Images[] getImages() {
		return images;
	}

}
