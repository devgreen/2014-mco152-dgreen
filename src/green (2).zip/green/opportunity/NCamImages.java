package green.opportunity;

public class NCamImages {

	Images[] images;

	public Images[] getImages() {
		return images;
	}

}
