package green.opportunity;

public class GetImages {

	Images[] images;

	public Images[] getImages() {
		return images;
	}

}
