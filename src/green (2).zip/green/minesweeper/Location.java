package green.minesweeper;

public class Location {

	private int i;
	private int j;

	public Location(int i, int j) {
		this.i=i;
		this.j=j;

	}

	public Location() {
		// TODO Auto-generated constructor stub
	}

	public int getI() {
		return i;
	}

	public int getJ() {
		return j;
	}

}
