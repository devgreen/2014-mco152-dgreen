package green.iss;

public class Res {

	private int risetime;

	public int getRisetime() {
		return risetime;
	}

}
